import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, Search, Edit2, Trash2, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const inventorySchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  description: z.string().optional(),
  category: z.string().min(1, "Categoria é obrigatória"),
  quantity: z.number().int().default(0),
  unitValue: z.string().or(z.number()),
  minThreshold: z.number().int().optional(),
  notes: z.string().optional(),
});

type InventoryFormData = z.infer<typeof inventorySchema>;

const CATEGORIES = [
  "Cabos",
  "Iluminação",
  "Som",
  "Estrutura",
  "Acessórios",
  "Combustível",
  "Manutenção",
  "Outro",
];

export default function Inventory() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("");
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const { data: items, isLoading, refetch } = trpc.inventory.list.useQuery({
    search: search || undefined,
    category: category || undefined,
  });

  const createMutation = trpc.inventory.create.useMutation();
  const updateMutation = trpc.inventory.update.useMutation();

  const { register, handleSubmit, reset, formState: { errors } } = useForm<any>({
    resolver: zodResolver(inventorySchema),
  });

  const onSubmit = async (data: InventoryFormData) => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...data });
      } else {
        await createMutation.mutateAsync(data);
      }
      reset();
      setIsOpen(false);
      setEditingId(null);
      refetch();
    } catch (error) {
      console.error("Erro ao salvar item:", error);
    }
  };

  const handleEdit = (item: any) => {
    setEditingId(item.id);
    reset({ ...item, unitValue: item.unitValue?.toString() || "0" });
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    setEditingId(null);
    reset();
  };

  if (!user) return null;

  const lowStockItems = items?.filter(item => (item.quantity || 0) <= (item.minThreshold || 5)) || [];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">ESTOQUE</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Controle de Equipamentos</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Low Stock Alert */}
        {lowStockItems.length > 0 && (
          <div className="mb-8 card-brutal bg-card border-primary">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-primary" />
              <h3 className="text-brutal-md">{lowStockItems.length} Itens com Estoque Baixo</h3>
            </div>
            <div className="space-y-2">
              {lowStockItems.map(item => (
                <div key={item.id} className="text-sm text-muted-foreground">
                  <span className="font-bold text-primary">{item.name}</span> - Quantidade: {item.quantity} (Mínimo: {item.minThreshold})
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou descrição..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 input-brutal"
              />
            </div>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="input-brutal"
            >
              <option value="">Todas as Categorias</option>
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="btn-brutal-primary" onClick={() => setEditingId(null)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Item
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-2 border-foreground max-w-2xl">
                <DialogHeader>
                  <DialogTitle className="text-brutal-md">
                    {editingId ? "Editar Item" : "Novo Item de Estoque"}
                  </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  {/* Name */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Nome *</label>
                    <Input {...register("name")} className="input-brutal" placeholder="Nome do equipamento" />
                    {errors.name && <p className="text-destructive text-sm mt-1">{(errors.name as any)?.message}</p>}
                  </div>

                  {/* Category and Quantity */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-brutal-sm mb-2 block">Categoria *</label>
                      <select {...register("category")} className="input-brutal w-full">
                        <option value="">Selecione...</option>
                        {CATEGORIES.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                      {errors.category && <p className="text-destructive text-sm mt-1">{(errors.category as any)?.message}</p>}
                    </div>
                    <div>
                      <label className="text-brutal-sm mb-2 block">Quantidade</label>
                      <Input {...register("quantity", { valueAsNumber: true })} type="number" className="input-brutal" placeholder="0" />
                    </div>
                  </div>

                  {/* Unit Value and Min Threshold */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-brutal-sm mb-2 block">Valor Unitário (R$)</label>
                      <Input {...register("unitValue")} type="number" step="0.01" className="input-brutal" placeholder="0.00" />
                    </div>
                    <div>
                      <label className="text-brutal-sm mb-2 block">Quantidade Mínima</label>
                      <Input {...register("minThreshold", { valueAsNumber: true })} type="number" className="input-brutal" placeholder="5" />
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Descrição</label>
                    <textarea
                      {...register("description")}
                      className="input-brutal w-full"
                      rows={2}
                      placeholder="Descrição do equipamento"
                    />
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Notas</label>
                    <textarea
                      {...register("notes")}
                      className="input-brutal w-full"
                      rows={2}
                      placeholder="Notas adicionais"
                    />
                  </div>

                  {/* Actions */}
                  <div className="flex gap-4 pt-4 border-t border-border">
                    <Button type="submit" className="btn-brutal-primary flex-1">
                      {editingId ? "Atualizar" : "Criar"} Item
                    </Button>
                    <Button type="button" variant="outline" className="flex-1" onClick={handleClose}>
                      Cancelar
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Items List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Carregando estoque...</p>
            </div>
          ) : items && items.length > 0 ? (
            items.map((item) => {
                      const isLowStock = (item.quantity || 0) <= (item.minThreshold || 5);
              return (
                <div
                  key={item.id}
                  className={`card-brutal border-foreground transition-colors ${isLowStock ? "border-primary bg-card/50" : ""}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-brutal-md">{item.name}</h3>
                        {isLowStock && (
                          <span className="badge-brutal text-xs">ESTOQUE BAIXO</span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Categoria:</span>
                          <p className="font-bold">{item.category}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Quantidade:</span>
                          <p className={`font-bold ${isLowStock ? "text-primary" : ""}`}>{item.quantity || 0}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Valor Unitário:</span>
                          <p className="font-bold">R$ {parseFloat(item.unitValue.toString()).toFixed(2)}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Total:</span>
                          <p className="font-bold">R$ {((item.quantity || 0) * parseFloat(item.unitValue.toString())).toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(item)}
                        className="border-foreground"
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 card-brutal bg-card border-foreground">
              <p className="text-muted-foreground mb-4">Nenhum item de estoque</p>
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-brutal-primary" onClick={() => setEditingId(null)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Primeiro Item
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
