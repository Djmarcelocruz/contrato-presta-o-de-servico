import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, FileText, Download, Eye } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const contractSchema = z.object({
  budgetId: z.number().min(1, "Orçamento é obrigatório"),
  clientId: z.number().min(1, "Cliente é obrigatório"),
  eventType: z.string().min(1, "Tipo de evento é obrigatório"),
  eventDate: z.date(),
  contractContent: z.string().min(10, "Conteúdo do contrato é obrigatório"),
});

type ContractFormData = z.infer<typeof contractSchema>;

const CONTRACT_TEMPLATES = {
  "Casamento": `CONTRATO DE PRESTAÇÃO DE SERVIÇOS - DJ PARA CASAMENTO

CONTRATANTE: [NOME DO CLIENTE]
CONTRATADA: DJ Brow

1. OBJETO DO CONTRATO
Prestação de serviço de DJ e sonorização para casamento.

2. DATA E LOCAL
Data: [DATA]
Local: [LOCAL]
Horário: [HORÁRIO]

3. VALORES E CONDIÇÕES
Valor total: R$ [VALOR]
Forma de pagamento: [FORMA]
Prazo de pagamento: [PRAZO]

4. RESPONSABILIDADES
- Fornecimento de equipamentos profissionais
- Animação musical durante o evento
- Suporte técnico durante toda a duração

5. CANCELAMENTO
Cancelamento com até 30 dias de antecedência: reembolso de 50%
Cancelamento com menos de 30 dias: sem reembolso

6. ASSINATURAS
_________________          _________________
Contratante                Contratada`,

  "Aniversário": `CONTRATO DE PRESTAÇÃO DE SERVIÇOS - DJ PARA ANIVERSÁRIO

CONTRATANTE: [NOME DO CLIENTE]
CONTRATADA: DJ Brow

1. OBJETO DO CONTRATO
Prestação de serviço de DJ e sonorização para festa de aniversário.

2. DATA E LOCAL
Data: [DATA]
Local: [LOCAL]
Horário: [HORÁRIO]

3. VALORES E CONDIÇÕES
Valor total: R$ [VALOR]
Forma de pagamento: [FORMA]

4. RESPONSABILIDADES
- Fornecimento de equipamentos de som e iluminação
- Animação musical e entretenimento
- Suporte técnico

5. ASSINATURAS
_________________          _________________
Contratante                Contratada`,

  "Corporativo": `CONTRATO DE PRESTAÇÃO DE SERVIÇOS - DJ PARA EVENTO CORPORATIVO

CONTRATANTE: [NOME DA EMPRESA]
CONTRATADA: DJ Brow

1. OBJETO DO CONTRATO
Prestação de serviço de DJ para evento corporativo.

2. DATA E LOCAL
Data: [DATA]
Local: [LOCAL]
Horário: [HORÁRIO]

3. VALORES E CONDIÇÕES
Valor total: R$ [VALOR]
Forma de pagamento: [FORMA]

4. RESPONSABILIDADES
- Sonorização profissional
- Animação musical
- Suporte técnico completo

5. ASSINATURAS
_________________          _________________
Contratante                Contratada`,
};

export default function Contracts() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("Casamento");

  const { data: budgets } = trpc.budgets.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm<ContractFormData>({
    resolver: zodResolver(contractSchema),
  });

  const createMutation = trpc.contracts.create.useMutation();

  const onSubmit = async (data: ContractFormData) => {
    try {
      await createMutation.mutateAsync({
        ...data,
        contractContent: data.contractContent,
        status: 'draft',
      } as any);
      reset();
      setIsOpen(false);
    } catch (error) {
      console.error("Erro ao criar contrato:", error);
    }
  };

  if (!user) return null;

  const eventType = watch('eventType');

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">CONTRATOS</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Gestão de Contratos de Serviço</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Create Button */}
        <div className="mb-8">
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="btn-brutal-primary">
                <Plus className="w-4 h-4 mr-2" />
                Novo Contrato
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-2 border-foreground max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-brutal-md">Criar Novo Contrato</DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                {/* Event Type */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Tipo de Evento *</label>
                  <select
                    {...register("eventType")}
                    onChange={(e) => {
                      register("eventType").onChange(e);
                      setSelectedTemplate(e.target.value);
                    }}
                    className="input-brutal w-full"
                  >
                    <option value="">Selecione...</option>
                    {Object.keys(CONTRACT_TEMPLATES).map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                  {errors.eventType && <p className="text-destructive text-sm mt-1">{(errors.eventType as any)?.message}</p>}
                </div>

                {/* Budget and Client */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">Orçamento *</label>
                    <select {...register("budgetId", { valueAsNumber: true })} className="input-brutal w-full">
                      <option value="">Selecione...</option>
                      {budgets?.map(budget => (
                        <option key={budget.id} value={budget.id}>
                          #{budget.id} - {budget.eventType}
                        </option>
                      ))}
                    </select>
                    {errors.budgetId && <p className="text-destructive text-sm mt-1">{(errors.budgetId as any)?.message}</p>}
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">Cliente *</label>
                    <select {...register("clientId", { valueAsNumber: true })} className="input-brutal w-full">
                      <option value="">Selecione...</option>
                      {clients?.map(client => (
                        <option key={client.id} value={client.id}>{client.name}</option>
                      ))}
                    </select>
                    {errors.clientId && <p className="text-destructive text-sm mt-1">{(errors.clientId as any)?.message}</p>}
                  </div>
                </div>

                {/* Event Date */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Data do Evento *</label>
                  <input {...register("eventDate", { valueAsDate: true })} type="date" className="input-brutal w-full" />
                  {errors.eventDate && <p className="text-destructive text-sm mt-1">{(errors.eventDate as any)?.message}</p>}
                </div>

                {/* Contract Content */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Conteúdo do Contrato *</label>
                  <textarea
                    {...register("contractContent")}
                    className="input-brutal w-full font-mono text-xs"
                    rows={12}
                    defaultValue={selectedTemplate ? CONTRACT_TEMPLATES[selectedTemplate as keyof typeof CONTRACT_TEMPLATES] : ""}
                  />
                  {errors.contractContent && <p className="text-destructive text-sm mt-1">{(errors.contractContent as any)?.message}</p>}
                </div>

                {/* Actions */}
                <div className="flex gap-4 pt-4 border-t border-border">
                  <Button type="submit" className="btn-brutal-primary flex-1">
                    Criar Contrato
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setIsOpen(false);
                      reset();
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Info */}
        <div className="card-brutal bg-card border-foreground mb-8">
          <div className="flex items-start gap-4">
            <FileText className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-brutal-md mb-2">Modelos de Contrato</h3>
              <p className="text-sm text-muted-foreground">
                O sistema fornece modelos de contrato pré-formatados para diferentes tipos de eventos.
                Você pode personalizá-los conforme necessário antes de enviar ao cliente.
              </p>
            </div>
          </div>
        </div>

        {/* Templates Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Object.keys(CONTRACT_TEMPLATES).map(type => (
            <div key={type} className="card-brutal bg-card border-foreground">
              <h4 className="text-brutal-sm mb-3">{type}</h4>
              <p className="text-xs text-muted-foreground mb-4 line-clamp-3">
                {CONTRACT_TEMPLATES[type as keyof typeof CONTRACT_TEMPLATES].substring(0, 150)}...
              </p>
              <Button variant="outline" size="sm" className="w-full border-foreground">
                <Eye className="w-4 h-4 mr-2" />
                Visualizar
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
