import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, Calendar, User, FileText, DollarSign } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";

const budgetSchema = z.object({
  clientId: z.number().min(1, "Cliente é obrigatório"),
  eventDate: z.date(),
  eventType: z.string().min(1, "Tipo de evento é obrigatório"),
  notes: z.string().optional(),
});

type BudgetFormData = z.infer<typeof budgetSchema>;

const EVENT_TYPES = [
  "Casamento",
  "Aniversário",
  "Formatura",
  "Corporativo",
  "Show",
  "Festa",
  "Conferência",
  "Outro",
];

export default function Budgets() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [dateConflict, setDateConflict] = useState<string | null>(null);

  const { data: clients } = trpc.clients.list.useQuery();
  const { data: budgets, isLoading, refetch } = trpc.budgets.list.useQuery();
  const createMutation = trpc.budgets.create.useMutation();

  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm<BudgetFormData>({
    resolver: zodResolver(budgetSchema),
  });

  const selectedDate = watch('eventDate');

  const onSubmit = async (data: BudgetFormData) => {
    try {
      setDateConflict(null);
      await createMutation.mutateAsync({
        ...data,
        status: 'draft',
      } as any);
      reset();
      setIsOpen(false);
      refetch();
    } catch (error: any) {
      if (error.message?.includes('conflito') || error.message?.includes('CONFLICT')) {
        setDateConflict('Já existe um evento agendado para esta data!');
      } else {
        console.error("Erro ao criar orçamento:", error);
      }
    }
  };

  if (!user) return null;

  const statusColors = {
    draft: "bg-card border-foreground",
    sent: "bg-card border-foreground",
    approved: "bg-card border-primary",
    rejected: "bg-card border-destructive",
    completed: "bg-card border-primary",
  };

  const statusLabels = {
    draft: "Rascunho",
    sent: "Enviado",
    approved: "Aprovado",
    rejected: "Rejeitado",
    completed: "Concluído",
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">ORÇAMENTOS</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Gestão de Orçamentos e Eventos</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Create Button */}
        <div className="mb-8">
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="btn-brutal-primary">
                <Plus className="w-4 h-4 mr-2" />
                Novo Orçamento
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-2 border-foreground max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-brutal-md">Criar Novo Orçamento</DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                {/* Date Conflict Alert */}
                {dateConflict && (
                  <div className="bg-destructive/20 border-2 border-destructive p-3 rounded-none">
                    <p className="text-destructive text-sm font-bold">{dateConflict}</p>
                  </div>
                )}

                {/* Client */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Cliente *</label>
                  <select {...register("clientId", { valueAsNumber: true })} className="input-brutal w-full">
                    <option value="">Selecione um cliente</option>
                    {clients?.map(client => (
                      <option key={client.id} value={client.id}>{client.name}</option>
                    ))}
                  </select>
                  {errors.clientId && <p className="text-destructive text-sm mt-1">{(errors.clientId as any)?.message}</p>}
                </div>

                {/* Event Date */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Data do Evento *</label>
                  <Input {...register("eventDate", { valueAsDate: true })} type="date" className="input-brutal" />
                  {errors.eventDate && <p className="text-destructive text-sm mt-1">{(errors.eventDate as any)?.message}</p>}
                </div>

                {/* Event Type */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Tipo de Evento *</label>
                  <select {...register("eventType")} className="input-brutal w-full">
                    <option value="">Selecione...</option>
                    {EVENT_TYPES.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                  {errors.eventType && <p className="text-destructive text-sm mt-1">{(errors.eventType as any)?.message}</p>}
                </div>

                {/* Notes */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Notas</label>
                  <textarea
                    {...register("notes")}
                    className="input-brutal w-full"
                    rows={3}
                    placeholder="Observações sobre o orçamento"
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-4 pt-4 border-t border-border">
                  <Button type="submit" className="btn-brutal-primary flex-1">
                    Criar Orçamento
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setIsOpen(false);
                      setDateConflict(null);
                      reset();
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Budgets List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Carregando orçamentos...</p>
            </div>
          ) : budgets && budgets.length > 0 ? (
            budgets.map((budget) => (
              <div
                key={budget.id}
                className={`card-brutal border-foreground transition-colors cursor-pointer hover:border-primary ${statusColors[budget.status as keyof typeof statusColors]}`}
                onClick={() => setLocation(`/budgets/${budget.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-brutal-md">{budget.eventType}</h3>
                      <span className="badge-brutal text-xs">{statusLabels[budget.status as keyof typeof statusLabels]}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <User className="w-4 h-4" />
                        <span>Cliente #{budget.clientId}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(budget.eventDate).toLocaleDateString('pt-BR')}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <DollarSign className="w-4 h-4" />
                        <span>R$ {parseFloat(budget.total.toString()).toFixed(2)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <FileText className="w-4 h-4" />
                        <span>ID: {budget.id}</span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-foreground"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/budgets/${budget.id}`);
                    }}
                  >
                    Visualizar
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 card-brutal bg-card border-foreground">
              <p className="text-muted-foreground mb-4">Nenhum orçamento criado</p>
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-brutal-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Criar Primeiro Orçamento
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
