import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, Download, Printer, DollarSign, Calendar, User } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const receiptSchema = z.object({
  budgetId: z.number().min(1, "Orçamento é obrigatório"),
  clientId: z.number().min(1, "Cliente é obrigatório"),
  paymentDate: z.date(),
  value: z.string().or(z.number()),
  paymentMethod: z.string().min(1, "Forma de pagamento é obrigatória"),
  description: z.string().optional(),
});

type ReceiptFormData = z.infer<typeof receiptSchema>;

const PAYMENT_METHODS = [
  "Dinheiro",
  "Cartão de Crédito",
  "Cartão de Débito",
  "Transferência Bancária",
  "PIX",
  "Cheque",
];

export default function Receipts() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const { data: receipts, isLoading, refetch } = trpc.receipts.list.useQuery();
  const { data: budgets } = trpc.budgets.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();

  const createMutation = trpc.receipts.create.useMutation();

  const { register, handleSubmit, reset, formState: { errors } } = useForm<ReceiptFormData>({
    resolver: zodResolver(receiptSchema),
    defaultValues: {
      paymentDate: new Date(),
    },
  });

  const onSubmit = async (data: ReceiptFormData) => {
    try {
      await createMutation.mutateAsync({
        ...data,
        value: typeof data.value === 'string' ? parseFloat(data.value) : data.value,
      });
      reset();
      setIsOpen(false);
      refetch();
    } catch (error) {
      console.error("Erro ao criar recibo:", error);
    }
  };

  if (!user) return null;

  const totalReceived = receipts?.reduce((sum, r) => sum + parseFloat(r.value.toString()), 0) || 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">RECIBOS</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Gestão de Recibos de Pagamento</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Summary */}
        <div className="card-brutal bg-card border-foreground mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-brutal-sm mb-2">Total Recebido</h3>
              <p className="text-3xl font-bold text-primary">R$ {totalReceived.toFixed(2)}</p>
            </div>
            <DollarSign className="w-12 h-12 text-primary opacity-20" />
          </div>
        </div>

        {/* Create Button */}
        <div className="mb-8">
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="btn-brutal-primary">
                <Plus className="w-4 h-4 mr-2" />
                Novo Recibo
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-2 border-foreground max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-brutal-md">Gerar Novo Recibo</DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                {/* Budget and Client */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">Orçamento *</label>
                    <select {...register("budgetId", { valueAsNumber: true })} className="input-brutal w-full">
                      <option value="">Selecione...</option>
                      {budgets?.map(budget => (
                        <option key={budget.id} value={budget.id}>
                          #{budget.id} - {budget.eventType}
                        </option>
                      ))}
                    </select>
                    {errors.budgetId && <p className="text-destructive text-sm mt-1">{(errors.budgetId as any)?.message}</p>}
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">Cliente *</label>
                    <select {...register("clientId", { valueAsNumber: true })} className="input-brutal w-full">
                      <option value="">Selecione...</option>
                      {clients?.map(client => (
                        <option key={client.id} value={client.id}>{client.name}</option>
                      ))}
                    </select>
                    {errors.clientId && <p className="text-destructive text-sm mt-1">{(errors.clientId as any)?.message}</p>}
                  </div>
                </div>

                {/* Payment Date and Value */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">Data de Pagamento *</label>
                    <Input {...register("paymentDate", { valueAsDate: true })} type="date" className="input-brutal" />
                    {errors.paymentDate && <p className="text-destructive text-sm mt-1">{(errors.paymentDate as any)?.message}</p>}
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">Valor (R$) *</label>
                    <Input {...register("value")} type="number" step="0.01" className="input-brutal" placeholder="0.00" />
                  </div>
                </div>

                {/* Payment Method */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Forma de Pagamento *</label>
                  <select {...register("paymentMethod")} className="input-brutal w-full">
                    <option value="">Selecione...</option>
                    {PAYMENT_METHODS.map(method => (
                      <option key={method} value={method}>{method}</option>
                    ))}
                  </select>
                  {errors.paymentMethod && <p className="text-destructive text-sm mt-1">{(errors.paymentMethod as any)?.message}</p>}
                </div>

                {/* Description */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Observações</label>
                  <textarea
                    {...register("description")}
                    className="input-brutal w-full"
                    rows={3}
                    placeholder="Observações adicionais"
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-4 pt-4 border-t border-border">
                  <Button type="submit" className="btn-brutal-primary flex-1">
                    Gerar Recibo
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setIsOpen(false);
                      reset();
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Receipts List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Carregando recibos...</p>
            </div>
          ) : receipts && receipts.length > 0 ? (
            receipts.map((receipt) => (
              <div key={receipt.id} className="card-brutal bg-card border-foreground">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-brutal-md">Recibo #{receipt.receiptNumber}</h3>
                      <span className="badge-brutal text-xs">ID: {receipt.id}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <User className="w-4 h-4" />
                        <span>Cliente #{receipt.clientId}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(receipt.paymentDate).toLocaleDateString('pt-BR')}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <DollarSign className="w-4 h-4" />
                        <span>R$ {parseFloat(receipt.value.toString()).toFixed(2)}</span>
                      </div>
                      <div className="text-muted-foreground">
                        <span className="font-bold">{receipt.paymentMethod}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="border-foreground">
                      <Printer className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" className="border-foreground">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 card-brutal bg-card border-foreground">
              <p className="text-muted-foreground mb-4">Nenhum recibo gerado</p>
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-brutal-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Gerar Primeiro Recibo
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
