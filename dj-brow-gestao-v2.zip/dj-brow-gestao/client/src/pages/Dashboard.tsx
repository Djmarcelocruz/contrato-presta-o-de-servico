import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { AlertCircle, Plus, TrendingUp, DollarSign, Package, Calendar } from "lucide-react";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [monthStart, setMonthStart] = useState(() => {
    const d = new Date();
    d.setDate(1);
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [monthEnd, setMonthEnd] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    d.setDate(0);
    d.setHours(23, 59, 59, 999);
    return d;
  });

  const { data: cashFlowSummary, isLoading: cashFlowLoading } = trpc.cashFlow.summary.useQuery({
    startDate: monthStart,
    endDate: monthEnd,
  });

  const { data: lowStockItems, isLoading: lowStockLoading } = trpc.inventory.lowStock.useQuery();

  const { data: budgets, isLoading: budgetsLoading } = trpc.budgets.list.useQuery();

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-pulse text-2xl font-bold text-foreground">Carregando...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Acesso Negado</h1>
          <p className="text-muted-foreground">Você precisa estar autenticado para acessar o sistema.</p>
        </div>
      </div>
    );
  }

  const profit = cashFlowSummary ? cashFlowSummary.totalIncome - cashFlowSummary.totalExpense : 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">Dashboard</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Resumo Financeiro e Gestão</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Welcome Section */}
        <div className="mb-12">
          <h2 className="text-brutal-md mb-6">Bem-vindo, {user.name || "Usuário"}</h2>
          <div className="h-0.5 bg-primary w-24 mb-8"></div>
        </div>

        {/* Financial Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {/* Total Income */}
          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Receitas</h3>
              <DollarSign className="w-6 h-6 text-primary" />
            </div>
            <div className="text-3xl font-bold text-primary mb-2">
              {cashFlowLoading ? "..." : `R$ ${(cashFlowSummary?.totalIncome || 0).toFixed(2)}`}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Este mês</p>
          </div>

          {/* Total Expenses */}
          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Despesas</h3>
              <TrendingUp className="w-6 h-6 text-foreground" />
            </div>
            <div className="text-3xl font-bold text-foreground mb-2">
              {cashFlowLoading ? "..." : `R$ ${(cashFlowSummary?.totalExpense || 0).toFixed(2)}`}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Este mês</p>
          </div>

          {/* Profit */}
          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Lucro</h3>
              <DollarSign className="w-6 h-6 text-primary" />
            </div>
            <div className={`text-3xl font-bold mb-2 ${profit >= 0 ? "text-primary" : "text-destructive"}`}>
              {cashFlowLoading ? "..." : `R$ ${profit.toFixed(2)}`}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Este mês</p>
          </div>

          {/* Upcoming Events */}
          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Eventos</h3>
              <Calendar className="w-6 h-6 text-foreground" />
            </div>
            <div className="text-3xl font-bold text-foreground mb-2">
              {budgetsLoading ? "..." : budgets?.length || 0}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Orçamentos</p>
          </div>
        </div>

        {/* Red Divider */}
        <div className="divider-red"></div>

        {/* Low Stock Alerts */}
        {lowStockItems && lowStockItems.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <AlertCircle className="w-6 h-6 text-primary" />
              <h3 className="text-brutal-md">Alertas de Estoque Baixo</h3>
            </div>
            <div className="h-0.5 bg-primary w-24 mb-6"></div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {lowStockItems.slice(0, 4).map((item) => (
                <div key={item.id} className="card-brutal bg-card border-primary">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-brutal-sm">{item.name}</h4>
                    <Package className="w-5 h-5 text-primary" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{item.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">
                      Quantidade: <span className="text-primary font-bold">{item.quantity}</span>
                    </span>
                    <span className="badge-brutal">Mínimo: {item.minThreshold}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className="mb-12">
          <h3 className="text-brutal-md mb-6">Ações Rápidas</h3>
          <div className="h-0.5 bg-primary w-24 mb-6"></div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => setLocation("/budgets/new")}
              className="btn-brutal-primary h-12 text-sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Orçamento
            </Button>
            <Button
              onClick={() => setLocation("/clients")}
              className="btn-brutal h-12 text-sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Cliente
            </Button>
            <Button
              onClick={() => setLocation("/inventory")}
              className="btn-brutal h-12 text-sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Equipamento
            </Button>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="divider-red"></div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <Button onClick={() => setLocation("/budgets")} variant="outline" className="h-12 text-xs">Orçamentos</Button>
          <Button onClick={() => setLocation("/cash-flow")} variant="outline" className="h-12 text-xs">Fluxo de Caixa</Button>
          <Button onClick={() => setLocation("/reports")} variant="outline" className="h-12 text-xs">Relatórios</Button>
          <Button onClick={() => setLocation("/clients")} variant="outline" className="h-12 text-xs">Clientes</Button>
          <Button onClick={() => setLocation("/inventory")} variant="outline" className="h-12 text-xs">Estoque</Button>
          <Button onClick={() => setLocation("/contracts")} variant="outline" className="h-12 text-xs">Contratos</Button>
          <Button onClick={() => setLocation("/receipts")} variant="outline" className="h-12 text-xs">Recibos</Button>
        </div>
      </div>
    </div>
  );
}
