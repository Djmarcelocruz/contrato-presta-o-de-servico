import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Download, TrendingUp, Calendar } from "lucide-react";
import { useState } from "react";

export default function Reports() {
  const { user } = useAuth();
  const [period, setPeriod] = useState<'month' | 'year'>('month');

  const [monthStart, setMonthStart] = useState(() => {
    const d = new Date();
    d.setDate(1);
    d.setHours(0, 0, 0, 0);
    return d;
  });

  const [monthEnd, setMonthEnd] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    d.setDate(0);
    d.setHours(23, 59, 59, 999);
    return d;
  });

  const { data: summary, isLoading } = trpc.cashFlow.summary.useQuery({
    startDate: monthStart,
    endDate: monthEnd,
  });

  if (!user) return null;

  const totalIncome = summary?.totalIncome || 0;
  const totalExpense = summary?.totalExpense || 0;
  const profit = totalIncome - totalExpense;
  const profitMargin = totalIncome > 0 ? ((profit / totalIncome) * 100).toFixed(1) : "0";

  // Mock data for charts
  const monthlyData = [
    { month: "Jan", receita: 2400, despesa: 1200, lucro: 1200 },
    { month: "Fev", receita: 3200, despesa: 1500, lucro: 1700 },
    { month: "Mar", receita: 2800, despesa: 1400, lucro: 1400 },
    { month: "Abr", receita: 3900, despesa: 1800, lucro: 2100 },
    { month: "Mai", receita: totalIncome, despesa: totalExpense, lucro: profit },
  ];

  const categoryData = [
    { name: "DJ", value: totalIncome * 0.6 },
    { name: "Aluguel", value: totalIncome * 0.25 },
    { name: "Técnico", value: totalIncome * 0.15 },
  ];

  const COLORS = ["#FF0000", "#FFFFFF", "#999999"];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">RELATÓRIOS</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Análise Financeira</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="card-brutal bg-card border-foreground">
            <h3 className="text-brutal-sm mb-2">Receita Total</h3>
            <p className="text-3xl font-bold text-primary mb-2">R$ {totalIncome.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">Este período</p>
          </div>

          <div className="card-brutal bg-card border-foreground">
            <h3 className="text-brutal-sm mb-2">Despesa Total</h3>
            <p className="text-3xl font-bold text-foreground mb-2">R$ {totalExpense.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">Este período</p>
          </div>

          <div className="card-brutal bg-card border-foreground">
            <h3 className="text-brutal-sm mb-2">Lucro Líquido</h3>
            <p className={`text-3xl font-bold mb-2 ${profit >= 0 ? 'text-primary' : 'text-destructive'}`}>
              R$ {profit.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground">Este período</p>
          </div>

          <div className="card-brutal bg-card border-foreground">
            <h3 className="text-brutal-sm mb-2">Margem de Lucro</h3>
            <p className="text-3xl font-bold text-primary mb-2">{profitMargin}%</p>
            <p className="text-xs text-muted-foreground">Percentual</p>
          </div>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Period Selector */}
        <div className="mb-8 flex gap-4">
          <Button
            onClick={() => setPeriod('month')}
            className={period === 'month' ? 'btn-brutal-primary' : 'btn-brutal'}
          >
            <Calendar className="w-4 h-4 mr-2" />
            Este Mês
          </Button>
          <Button
            onClick={() => setPeriod('year')}
            className={period === 'year' ? 'btn-brutal-primary' : 'btn-brutal'}
          >
            <Calendar className="w-4 h-4 mr-2" />
            Este Ano
          </Button>
          <Button variant="outline" className="border-foreground ml-auto">
            <Download className="w-4 h-4 mr-2" />
            Exportar PDF
          </Button>
        </div>

        {/* Charts */}
        <div className="space-y-12">
          {/* Monthly Trend */}
          <div className="card-brutal bg-card border-foreground p-6">
            <h3 className="text-brutal-md mb-6">Tendência Mensal</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="month" stroke="#fff" />
                <YAxis stroke="#fff" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '2px solid #fff' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Line type="monotone" dataKey="receita" stroke="#FF0000" strokeWidth={2} name="Receita" />
                <Line type="monotone" dataKey="despesa" stroke="#999" strokeWidth={2} name="Despesa" />
                <Line type="monotone" dataKey="lucro" stroke="#FF0000" strokeWidth={2} strokeDasharray="5 5" name="Lucro" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Revenue by Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card-brutal bg-card border-foreground p-6">
              <h3 className="text-brutal-md mb-6">Receita por Categoria</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: R$ ${value.toFixed(0)}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: any) => `R$ ${typeof value === 'number' ? value.toFixed(2) : value}`} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Key Metrics */}
            <div className="space-y-4">
              <div className="card-brutal bg-card border-foreground p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-brutal-sm">Ticket Médio</h4>
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <p className="text-2xl font-bold text-primary">R$ 1.850,00</p>
              </div>

              <div className="card-brutal bg-card border-foreground p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-brutal-sm">Eventos Realizados</h4>
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <p className="text-2xl font-bold text-primary">12</p>
              </div>

              <div className="card-brutal bg-card border-foreground p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-brutal-sm">Taxa de Conversão</h4>
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <p className="text-2xl font-bold text-primary">75%</p>
              </div>
            </div>
          </div>

          {/* Comparison */}
          <div className="card-brutal bg-card border-foreground p-6">
            <h3 className="text-brutal-md mb-6">Comparação Receita vs Despesa</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="month" stroke="#fff" />
                <YAxis stroke="#fff" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '2px solid #fff' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Bar dataKey="receita" fill="#FF0000" name="Receita" />
                <Bar dataKey="despesa" fill="#666" name="Despesa" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
