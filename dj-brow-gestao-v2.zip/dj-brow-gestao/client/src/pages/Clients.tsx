import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, Search, Edit2, Trash2, Phone, Mail, MapPin } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const clientSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  cpf: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().max(2).optional(),
  cep: z.string().optional(),
  notes: z.string().optional(),
});

type ClientFormData = z.infer<typeof clientSchema>;

export default function Clients() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const { data: clients, isLoading, refetch } = trpc.clients.list.useQuery({ search: search || undefined });
  const createMutation = trpc.clients.create.useMutation();
  const updateMutation = trpc.clients.update.useMutation();

  const { register, handleSubmit, reset, formState: { errors } } = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
  });

  const onSubmit = async (data: ClientFormData) => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...data });
      } else {
        await createMutation.mutateAsync(data);
      }
      reset();
      setIsOpen(false);
      setEditingId(null);
      refetch();
    } catch (error) {
      console.error("Erro ao salvar cliente:", error);
    }
  };

  const handleEdit = (client: any) => {
    setEditingId(client.id);
    reset(client);
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    setEditingId(null);
    reset();
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">CLIENTES</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Gestão de Clientes</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Search and Actions */}
        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, telefone ou CPF..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 input-brutal"
            />
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="btn-brutal-primary" onClick={() => setEditingId(null)}>
                <Plus className="w-4 h-4 mr-2" />
                Novo Cliente
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-2 border-foreground max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-brutal-md">
                  {editingId ? "Editar Cliente" : "Novo Cliente"}
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                {/* Name */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Nome *</label>
                  <Input {...register("name")} className="input-brutal" placeholder="Nome completo" />
                  {errors.name && <p className="text-destructive text-sm mt-1">{errors.name.message}</p>}
                </div>

                {/* CPF and Phone */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">CPF</label>
                    <Input {...register("cpf")} className="input-brutal" placeholder="000.000.000-00" />
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">Telefone</label>
                    <Input {...register("phone")} className="input-brutal" placeholder="(00) 99999-9999" />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Email</label>
                  <Input {...register("email")} className="input-brutal" type="email" placeholder="email@example.com" />
                  {errors.email && <p className="text-destructive text-sm mt-1">{errors.email.message}</p>}
                </div>

                {/* Address */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Endereço</label>
                  <Input {...register("address")} className="input-brutal" placeholder="Rua, número, complemento" />
                </div>

                {/* City, State, CEP */}
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">Cidade</label>
                    <Input {...register("city")} className="input-brutal" placeholder="Cidade" />
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">UF</label>
                    <Input {...register("state")} className="input-brutal" placeholder="SP" maxLength={2} />
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">CEP</label>
                    <Input {...register("cep")} className="input-brutal" placeholder="00000-000" />
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Notas</label>
                  <textarea
                    {...register("notes")}
                    className="input-brutal w-full"
                    rows={3}
                    placeholder="Notas adicionais sobre o cliente"
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-4 pt-4 border-t border-border">
                  <Button type="submit" className="btn-brutal-primary flex-1">
                    {editingId ? "Atualizar" : "Criar"} Cliente
                  </Button>
                  <Button type="button" variant="outline" className="flex-1" onClick={handleClose}>
                    Cancelar
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Clients List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Carregando clientes...</p>
            </div>
          ) : clients && clients.length > 0 ? (
            clients.map((client) => (
              <div key={client.id} className="card-brutal bg-card border-foreground hover:border-primary transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-brutal-md mb-3">{client.name}</h3>
                    <div className="space-y-2 text-sm">
                      {client.phone && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Phone className="w-4 h-4" />
                          <span>{client.phone}</span>
                        </div>
                      )}
                      {client.email && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Mail className="w-4 h-4" />
                          <span>{client.email}</span>
                        </div>
                      )}
                      {client.address && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          <span>{client.address}, {client.city} - {client.state}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(client)}
                      className="border-foreground"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 card-brutal bg-card border-foreground">
              <p className="text-muted-foreground mb-4">Nenhum cliente encontrado</p>
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-brutal-primary" onClick={() => setEditingId(null)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Criar Primeiro Cliente
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
