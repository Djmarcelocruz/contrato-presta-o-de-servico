import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, TrendingUp, TrendingDown, Calendar } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const cashFlowSchema = z.object({
  date: z.date(),
  type: z.enum(['income', 'expense']),
  category: z.string().min(1, "Categoria é obrigatória"),
  value: z.string().or(z.number()),
  description: z.string().optional(),
});

type CashFlowFormData = z.infer<typeof cashFlowSchema>;

const CATEGORIES = {
  income: ["DJ", "Aluguel Equipamentos", "Serviço Técnico", "Outro"],
  expense: ["Combustível", "Manutenção", "Som", "Iluminação", "Estrutura", "Alimentação", "Pedágio", "Outro"],
};

export default function CashFlow() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [monthStart, setMonthStart] = useState(() => {
    const d = new Date();
    d.setDate(1);
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [monthEnd, setMonthEnd] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    d.setDate(0);
    d.setHours(23, 59, 59, 999);
    return d;
  });

  const { data: summary, isLoading: summaryLoading, refetch: refetchSummary } = trpc.cashFlow.summary.useQuery({
    startDate: monthStart,
    endDate: monthEnd,
  });

  const createMutation = trpc.cashFlow.create.useMutation();

  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm<CashFlowFormData>({
    resolver: zodResolver(cashFlowSchema),
    defaultValues: {
      date: new Date(),
      type: 'income',
    },
  });

  const selectedType = watch('type');

  const onSubmit = async (data: CashFlowFormData) => {
    try {
      await createMutation.mutateAsync({
        ...data,
        value: typeof data.value === 'string' ? parseFloat(data.value) : data.value,
      });
      reset();
      setIsOpen(false);
      refetchSummary();
    } catch (error) {
      console.error("Erro ao registrar:", error);
    }
  };

  if (!user) return null;

  const entries = summary?.entries || [];
  const totalIncome = summary?.totalIncome || 0;
  const totalExpense = summary?.totalExpense || 0;
  const profit = summary?.profit || 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">FLUXO DE CAIXA</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Entradas e Saídas</p>
        </div>
      </div>

      <div className="container pb-12">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Entradas</h3>
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
            <div className="text-3xl font-bold text-primary mb-2">
              {summaryLoading ? "..." : `R$ ${totalIncome.toFixed(2)}`}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Este mês</p>
          </div>

          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Saídas</h3>
              <TrendingDown className="w-6 h-6 text-foreground" />
            </div>
            <div className="text-3xl font-bold text-foreground mb-2">
              {summaryLoading ? "..." : `R$ ${totalExpense.toFixed(2)}`}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Este mês</p>
          </div>

          <div className="card-brutal bg-card border-foreground">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-brutal-sm">Saldo</h3>
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
            <div className={`text-3xl font-bold mb-2 ${profit >= 0 ? "text-primary" : "text-destructive"}`}>
              {summaryLoading ? "..." : `R$ ${profit.toFixed(2)}`}
            </div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Este mês</p>
          </div>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Add Entry Button */}
        <div className="mb-8">
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="btn-brutal-primary">
                <Plus className="w-4 h-4 mr-2" />
                Registrar Movimento
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-2 border-foreground max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-brutal-md">Registrar Movimento Financeiro</DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                {/* Type */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">Tipo *</label>
                    <select {...register("type")} className="input-brutal w-full">
                      <option value="income">Entrada (Receita)</option>
                      <option value="expense">Saída (Despesa)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">Data *</label>
                    <Input {...register("date", { valueAsDate: true })} type="date" className="input-brutal" />
                  </div>
                </div>

                {/* Category and Value */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-brutal-sm mb-2 block">Categoria *</label>
                    <select {...register("category")} className="input-brutal w-full">
                      <option value="">Selecione...</option>
                      {CATEGORIES[selectedType as keyof typeof CATEGORIES].map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                    {errors.category && <p className="text-destructive text-sm mt-1">{(errors.category as any)?.message}</p>}
                  </div>
                  <div>
                    <label className="text-brutal-sm mb-2 block">Valor (R$) *</label>
                    <Input {...register("value")} type="number" step="0.01" className="input-brutal" placeholder="0.00" />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="text-brutal-sm mb-2 block">Descrição</label>
                  <textarea
                    {...register("description")}
                    className="input-brutal w-full"
                    rows={3}
                    placeholder="Descrição do movimento"
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-4 pt-4 border-t border-border">
                  <Button type="submit" className="btn-brutal-primary flex-1">
                    Registrar
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setIsOpen(false);
                      reset();
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Divider */}
        <div className="divider-red"></div>

        {/* Entries List */}
        <div className="space-y-4">
          {summaryLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Carregando movimentos...</p>
            </div>
          ) : entries.length > 0 ? (
            entries.map((entry) => (
              <div key={entry.id} className="card-brutal bg-card border-foreground">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    {entry.type === 'income' ? (
                      <TrendingUp className="w-6 h-6 text-primary flex-shrink-0" />
                    ) : (
                      <TrendingDown className="w-6 h-6 text-foreground flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <h3 className="text-brutal-sm">{entry.category}</h3>
                      <p className="text-sm text-muted-foreground">{entry.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        <Calendar className="w-3 h-3 inline mr-1" />
                        {new Date(entry.date).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  </div>
                  <div className={`text-2xl font-bold text-right ${entry.type === 'income' ? 'text-primary' : 'text-foreground'}`}>
                    {entry.type === 'income' ? '+' : '-'} R$ {parseFloat(entry.value.toString()).toFixed(2)}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 card-brutal bg-card border-foreground">
              <p className="text-muted-foreground mb-4">Nenhum movimento registrado</p>
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-brutal-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Registrar Primeiro Movimento
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
