import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Settings, LogOut, User, Bell, Lock } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const settingsSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  businessName: z.string().optional(),
  businessPhone: z.string().optional(),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'security'>('profile');
  const [isSaving, setIsSaving] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      name: user?.name || '',
      email: user?.email || '',
    },
  });

  const onSubmit = async (data: SettingsFormData) => {
    setIsSaving(true);
    try {
      // TODO: Implement update user profile mutation
      console.log("Saving settings:", data);
      setIsSaving(false);
    } catch (error) {
      console.error("Erro ao salvar configurações:", error);
      setIsSaving(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b-2 border-foreground py-8 mb-12">
        <div className="container">
          <h1 className="text-brutal-lg mb-2">CONFIGURAÇÕES</h1>
          <div className="h-1 bg-primary w-32 mb-4"></div>
          <p className="text-muted-foreground text-sm uppercase tracking-widest">Perfil e Preferências</p>
        </div>
      </div>

      <div className="container pb-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Sidebar Navigation */}
          <div className="md:col-span-1">
            <div className="space-y-2">
              <button
                onClick={() => setActiveTab('profile')}
                className={`w-full text-left px-4 py-3 border-2 transition-colors ${
                  activeTab === 'profile'
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-foreground text-muted-foreground hover:border-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span className="text-sm font-bold">Perfil</span>
                </div>
              </button>

              <button
                onClick={() => setActiveTab('notifications')}
                className={`w-full text-left px-4 py-3 border-2 transition-colors ${
                  activeTab === 'notifications'
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-foreground text-muted-foreground hover:border-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  <span className="text-sm font-bold">Notificações</span>
                </div>
              </button>

              <button
                onClick={() => setActiveTab('security')}
                className={`w-full text-left px-4 py-3 border-2 transition-colors ${
                  activeTab === 'security'
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-foreground text-muted-foreground hover:border-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  <span className="text-sm font-bold">Segurança</span>
                </div>
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="md:col-span-3">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="card-brutal bg-card border-foreground p-6">
                <h2 className="text-brutal-md mb-6">Informações do Perfil</h2>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  {/* Name */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Nome Completo</label>
                    <Input {...register("name")} className="input-brutal" />
                    {errors.name && <p className="text-destructive text-sm mt-1">{(errors.name as any)?.message}</p>}
                  </div>

                  {/* Email */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Email</label>
                    <Input {...register("email")} type="email" className="input-brutal" />
                    {errors.email && <p className="text-destructive text-sm mt-1">{(errors.email as any)?.message}</p>}
                  </div>

                  {/* Business Name */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Nome do Negócio</label>
                    <Input {...register("businessName")} className="input-brutal" placeholder="DJ Brow" />
                  </div>

                  {/* Business Phone */}
                  <div>
                    <label className="text-brutal-sm mb-2 block">Telefone do Negócio</label>
                    <Input {...register("businessPhone")} className="input-brutal" placeholder="(11) 9999-9999" />
                  </div>

                  {/* Actions */}
                  <div className="flex gap-4 pt-4 border-t border-border">
                    <Button type="submit" className="btn-brutal-primary flex-1" disabled={isSaving}>
                      {isSaving ? "Salvando..." : "Salvar Alterações"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => logout()}
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair
                    </Button>
                  </div>
                </form>
              </div>
            )}

            {/* Notifications Tab */}
            {activeTab === 'notifications' && (
              <div className="card-brutal bg-card border-foreground p-6">
                <h2 className="text-brutal-md mb-6">Preferências de Notificações</h2>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border-2 border-foreground">
                    <div>
                      <h3 className="font-bold">Alertas de Estoque Baixo</h3>
                      <p className="text-sm text-muted-foreground">Receba notificações quando estoque estiver baixo</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>

                  <div className="flex items-center justify-between p-4 border-2 border-foreground">
                    <div>
                      <h3 className="font-bold">Novos Orçamentos</h3>
                      <p className="text-sm text-muted-foreground">Notifique-me sobre novos orçamentos criados</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>

                  <div className="flex items-center justify-between p-4 border-2 border-foreground">
                    <div>
                      <h3 className="font-bold">Pagamentos Recebidos</h3>
                      <p className="text-sm text-muted-foreground">Notifique-me quando receber pagamentos</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>

                  <div className="flex items-center justify-between p-4 border-2 border-foreground">
                    <div>
                      <h3 className="font-bold">Próximos Eventos</h3>
                      <p className="text-sm text-muted-foreground">Lembrete de eventos agendados</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>

                  <div className="pt-4 border-t border-border">
                    <Button className="btn-brutal-primary">Salvar Preferências</Button>
                  </div>
                </div>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="card-brutal bg-card border-foreground p-6">
                <h2 className="text-brutal-md mb-6">Segurança</h2>

                <div className="space-y-6">
                  {/* Session Info */}
                  <div className="p-4 border-2 border-foreground">
                    <h3 className="font-bold mb-3">Informações da Sessão</h3>
                    <div className="space-y-2 text-sm">
                      <p><span className="text-muted-foreground">ID do Usuário:</span> {user.id}</p>
                      <p><span className="text-muted-foreground">Método de Login:</span> {user.loginMethod}</p>
                      <p><span className="text-muted-foreground">Último Acesso:</span> {new Date(user.lastSignedIn).toLocaleString('pt-BR')}</p>
                      <p><span className="text-muted-foreground">Conta Criada:</span> {new Date(user.createdAt).toLocaleString('pt-BR')}</p>
                    </div>
                  </div>

                  {/* Data Privacy */}
                  <div className="p-4 border-2 border-foreground">
                    <h3 className="font-bold mb-3">Privacidade de Dados</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Seus dados sensíveis (CPF, telefone, endereço) são criptografados e armazenados com segurança.
                      Nenhuma informação pessoal é compartilhada com terceiros.
                    </p>
                    <Button variant="outline" className="border-foreground">
                      Ver Política de Privacidade
                    </Button>
                  </div>

                  {/* Logout All Sessions */}
                  <div className="pt-4 border-t border-border">
                    <Button variant="destructive" className="w-full">
                      Sair de Todas as Sessões
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
